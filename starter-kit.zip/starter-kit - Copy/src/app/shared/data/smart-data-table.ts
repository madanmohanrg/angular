// Smart DataTable
export var alertsettings = {
  actions: {
    add: false,
    edit: false,
    custom: [{ name: 'ourCustomAction', title: '<i class="ft-edit-2 info font-medium-1 mr-2"></i>' }],
    position: 'right'
  },
  delete: {
    confirmDelete: true,
    deleteButtonContent: '<i class="ft-x danger font-medium-1 mr-2"></i>'
  },
  add: {
    confirmCreate: true,
  },
  edit: {
    confirmSave: true,
    editButtonContent: '<i class="ft-edit-2 info font-medium-1 mr-2"></i>'
  },
  columns: {
    id: {
      title: 'ID',
      type: 'text'
    },
    name: {
      title: 'Full Name',
    },
    username: {
      title: 'User Name',
    },
    email: {
      title: 'Email',
    },
  },
  attr: {
    class: "table table-responsive"
  },
};