import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {HttpErrorResponse} from '@angular/common/http';

@Injectable()
export class TableService {
  constructor(private http: HttpClient) { }
  url = 'http://localhost:4000';
  getCharacters() {
    return this.http.get(`${this.url}/characters`);
  }

  deleteRecord(event){
    console.log(event.data);
    this.http.delete<any>(`${this.url}/characters/`+event.data.id).subscribe(
    res => {
      console.log(res);
      event.confirm.resolve(event.source.data);
      alert('Record Deleted Successfully.');
    },
    (err: HttpErrorResponse) => {
      if (err.error instanceof Error) {
        console.log("Client-side error occured.");
      } else {
        console.log("Server-side error occured.");
      }
    });
  }
}