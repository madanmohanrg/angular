export interface Table {
    id: Number;
    name: String;
    username: String;
    email: String;
}