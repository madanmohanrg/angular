import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import * as tableData from '../../shared/data/smart-data-table';
import { LocalDataSource } from 'ng2-smart-table';
import { Router } from '@angular/router';
import { TableService } from './table.service';
import { Table } from './Table';

@Component({
    selector: 'app-smart-data-table',
    templateUrl: './smart-data-table.component.html',
    styleUrls: ['./smart-data-table.component.scss'],
    encapsulation: ViewEncapsulation.None
})

export class SmartTableComponent implements OnInit {
    alertSource: LocalDataSource;
    characters: Table[];

    constructor(private router: Router, private tservice: TableService) {
        this.alertSource = new LocalDataSource(this.characters); // create the source
    }

    alertsettings = tableData.alertsettings;

    ngOnInit() {
        this.tservice.getCharacters()
          .subscribe((data: Table[]) => {
            this.characters = data;
        });
      }

    onCustomAction(event) {
        alert(event.data.id);
        this.router.navigate(['/full-layout']);
    }

    //  For confirm action On Delete
    onDeleteConfirm(event) {
        if (window.confirm('Are you sure you want to delete?')) {
            this.tservice.deleteRecord(event);
        } else {
            event.confirm.reject();
        }
    }

    //  For confirm action On Save
    onSaveConfirm(event) {
        if (window.confirm('Are you sure you want to save?')) {
            event.newData['name'] += ' + added in code';
            event.confirm.resolve(event.newData);
        } else {
            event.confirm.reject();
        }
    }

    //  For confirm action On Create
    onCreateConfirm(event) {
        if (window.confirm('Are you sure you want to create?')) {
            event.newData['name'] += ' + added in code';
            event.confirm.resolve(event.newData);
        } else {
            event.confirm.reject();
        }
    }

}